#!/bin/sh

print_usage() {
    echo "Usage: $0 [Command] [Options]"
    echo ""
    echo "Command:"
    echo "  all                         生成所有证书 (默认)"
    echo "  ca                          生成根 CA 证书"
    echo "  server                      生成服务端证书"
    echo "  client                      生成客户端证书"
    echo "  clean                       删除当前目录下的所有证书文件"
    echo ""
    echo "Options:"
    echo "  --algo [rsa|ecc|sm2]        指定密钥算法 (默认: ecc)"
    echo "  --ca <ca_base>              CA 证书和密钥前缀路径 (默认: tls_certs/ca/ca)"
    echo "  --s <server_base>           服务端证书和密钥前缀路径 (默认: tls_certs/server/server)"
    echo "  --c <client_base>           客户端证书和密钥前缀路径 (默认: tls_certs/client/client)"
    echo "  --serial <ca_serial_file>   序列号文件 (默认: tls_certs/ca/Quant360_ca_serial.cert.srl)"
    echo "  --org <org_name>            组织名称 (默认: Quant360)"
    echo "  --st <state_or_province>    省份 (默认: Dev)"
    echo "  --locality <locality>       城市或区域 (默认: Local)"
    echo "  --days <days>               证书有效期 (默认: 3650)"
    echo "  --openssl-bin <path>        指定 OpenSSL 可执行文件路径 (默认: openssl)"
    echo "  --openssl-lib <path>        指定 OpenSSL 库路径"
    echo ""
    exit 1
}

# 默认参数
ALGO="ecc"
DAYS="3650"
CA_BASE="tls_certs/ca/ca"
SERVER_BASE="tls_certs/server/server"
CLIENT_BASE="tls_certs/client/client"
SERVER_NAME=""
CLIENT_NAME=""
ORG_NAME="Quant360"
CA_SERIAL_FILE="tls_certs/ca/${ORG_NAME}_ca_serial.cert.srl"
ST_NAME="Dev"
LOCALITY_NAME="Local"
OPENSSL_BIN="openssl"
OPENSSL_LIB=""

GEN_CA=0
GEN_SERVER=0
GEN_CLIENT=0
GEN_VERBOSE=0

# 解析参数
while [ $# -gt 0 ]; do
    case "$1" in
        all) GEN_CA=1; GEN_SERVER=1; GEN_CLIENT=1 ;;
        ca) GEN_CA=1 ;;
        server) GEN_SERVER=1 ;;
        client) GEN_CLIENT=1 ;;
        clean) rm -f *.cert.srl *.cert.pem *.key.pem *.pfx; exit 0 ;;

        --algo) shift; ALGO="$1" ;;
        --ca) shift; CA_BASE="$1" ;;
        --s) shift; SERVER_BASE="$1" ;;
        --c) shift; CLIENT_BASE="$1" ;;
        --serial) shift; CA_SERIAL_FILE="$1" ;;
        --org) shift; ORG_NAME="$1" ;;
        --st) shift; ST_NAME="$1" ;;
        --locality) shift; LOCALITY_NAME="$1" ;;
        --days) shift; DAYS="$1" ;;
        --openssl-bin) shift; OPENSSL_BIN="$1" ;;
        --openssl-lib) shift; OPENSSL_LIB="$1" ;;
        -v) GEN_VERBOSE=1 ;;

        *) print_usage ;;
    esac
    shift
done

# 设置 OpenSSL 环境
if [ -n "$OPENSSL_LIB" ]; then
    export LD_LIBRARY_PATH="$OPENSSL_LIB:$LD_LIBRARY_PATH"
    # macOS 使用 DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH="$OPENSSL_LIB:$DYLD_LIBRARY_PATH"
    echo "==> 设置 OpenSSL 库路径: $OPENSSL_LIB"
fi

# 检查 OpenSSL 是否可用
if ! "$OPENSSL_BIN" version > /dev/null 2>&1; then
    echo "错误: 无法执行 OpenSSL 命令: $OPENSSL_BIN"
    echo "请确保 OpenSSL 已正确安装或使用 --openssl-bin 指定正确的路径"
    exit 1
fi

# 默认行为: 生成全部
if [ "$GEN_CA" = "0" ] && [ "$GEN_SERVER" = "0" ] && [ "$GEN_CLIENT" = "0" ]; then
    GEN_CA=1
    GEN_SERVER=1
    GEN_CLIENT=1
fi

CA_CERT="${CA_BASE}.cert.pem"
CA_KEY="${CA_BASE}.key.pem"

SERVER_CERT="${SERVER_BASE}.cert.pem"
SERVER_KEY="${SERVER_BASE}.key.pem"
SERVER_PFX="${SERVER_BASE}.pfx"

CLIENT_CERT="${CLIENT_BASE}.cert.pem"
CLIENT_KEY="${CLIENT_BASE}.key.pem"
CLIENT_PFX="${CLIENT_BASE}.pfx"

SERVER_NAME="`basename "$SERVER_BASE"`"
CLIENT_NAME="`basename "$CLIENT_BASE"`"

echo "--------------------------------------------"
echo ">>> CA_BASE    : $CA_BASE"
echo ">>> SERVER_BASE: $SERVER_BASE"
echo ">>> CLIENT_BASE: $CLIENT_BASE"
echo ">>> SERIAL_FILE: $CA_SERIAL_FILE"
echo "--------------------------------------------"
echo ">>> SERVER_NAME: $SERVER_NAME"
echo ">>> CLIENT_NAME: $CLIENT_NAME"
echo ">>> ORG_NAME   : $ORG_NAME"
echo ">>> ST         : $ST_NAME"
echo ">>> LOCALITY   : $LOCALITY_NAME"
echo ">>> DAYS       : $DAYS"
echo ">>> ALGO       : $ALGO"
echo ">>> OPENSSL    : $OPENSSL_BIN"
if [ -n "$OPENSSL_LIB" ]; then
    echo ">>> OPENSSL_LIB: $OPENSSL_LIB"
fi
echo "--------------------------------------------"
echo ""

mkdir -p "`dirname "$CA_BASE"`"
mkdir -p "`dirname "$SERVER_BASE"`"
mkdir -p "`dirname "$CLIENT_BASE"`"

# 获取适当的摘要算法
get_DIGEST() {
    if [ "$ALGO" = "sm2" ]; then
        echo "sm3"
    else
        echo "sha256"
    fi
}

generate_key() {
    key_path="$1"
    if [ "$ALGO" = "rsa" ]; then
        "$OPENSSL_BIN" genpkey \
            -algorithm RSA \
            -pkeyopt rsa_keygen_bits:2048 \
            -out "$key_path"
    elif [ "$ALGO" = "sm2" ]; then
        "$OPENSSL_BIN" ecparam \
            -name SM2 \
            -genkey \
            -noout \
            -out "$key_path"
    else
        "$OPENSSL_BIN" ecparam \
            -name prime256v1 \
            -genkey \
            -noout \
            -out "$key_path"
    fi
}

generate_ca() {
    echo "==> 生成 CA 根证书"
    generate_key "$CA_KEY"

    DIGEST=$(get_DIGEST)

    "$OPENSSL_BIN" req -x509 -new \
        -key "$CA_KEY" \
        -"$DIGEST" \
        -days "$DAYS" \
        -subj "/C=CN/ST=$ST_NAME/L=$LOCALITY_NAME/O=$ORG_NAME/CN=$ORG_NAME Root CA" \
        -out "$CA_CERT"

    echo ""
    if [ "$GEN_VERBOSE" = "1" ]; then
        echo "--> 打印 CA 根证书"
        "$OPENSSL_BIN" x509 -in "$CA_CERT" -text -noout
        echo ""
    fi
}

generate_server_cert() {
    echo "==> 生成服务端证书"
    generate_key "$SERVER_KEY"

    DIGEST=$(get_DIGEST)

    cat > server.cnf <<EOF
[ req ]
prompt              = no
distinguished_name  = dn
req_extensions      = ext
default_md          = $DIGEST

[ dn ]
C                   = CN
ST                  = $ST_NAME
L                   = $LOCALITY_NAME
O                   = $ORG_NAME
CN                  = $SERVER_NAME

[ ext ]
subjectAltName      = @alt_names

[ alt_names ]
DNS.1               = $SERVER_NAME
URI.1               = spiffe://$ORG_NAME.com/service/$SERVER_NAME
EOF

    "$OPENSSL_BIN" req -new \
        -key "$SERVER_KEY" \
        -out server.csr.pem \
        -config server.cnf

    "$OPENSSL_BIN" x509 -req \
        -in server.csr.pem \
        -CA "$CA_CERT" \
        -CAkey "$CA_KEY" \
        -CAcreateserial -CAserial $CA_SERIAL_FILE \
        -out "$SERVER_CERT" \
        -days "$DAYS" \
        -"$DIGEST" \
        -extfile server.cnf \
        -extensions ext

    "$OPENSSL_BIN" pkcs12 -export \
        -in "$SERVER_CERT" \
        -inkey "$SERVER_KEY" \
        -certfile "$CA_CERT" \
        -out "$SERVER_PFX" \
        -certpbe AES-256-CBC \
        -keypbe AES-256-CBC \
        -macalg sha256 \
        -passout pass:

    rm -f server.csr.pem server.cnf

    echo ""
    if [ "$GEN_VERBOSE" = "1" ]; then
        echo "--> 打印服务端证书"
        "$OPENSSL_BIN" x509 -in "$SERVER_CERT" -text -noout
        echo ""
    fi
}

generate_client_cert() {
    echo "==> 生成客户端证书"
    generate_key "$CLIENT_KEY"

    DIGEST=$(get_DIGEST)

    cat > client.cnf <<EOF
[ req ]
prompt              = no
distinguished_name  = dn
req_extensions      = ext
default_md          = $DIGEST

[ dn ]
C                   = CN
ST                  = $ST_NAME
L                   = $LOCALITY_NAME
O                   = $ORG_NAME
CN                  = $CLIENT_NAME

[ ext ]
subjectAltName      = @alt_names

[ alt_names ]
DNS.1               = $CLIENT_NAME
URI.1               = spiffe://$ORG_NAME.com/user/$CLIENT_NAME
EOF

    "$OPENSSL_BIN" req -new \
        -key "$CLIENT_KEY" \
        -out client.csr.pem \
        -config client.cnf

    "$OPENSSL_BIN" x509 -req \
        -in client.csr.pem \
        -CA "$CA_CERT" \
        -CAkey "$CA_KEY" \
        -CAcreateserial -CAserial $CA_SERIAL_FILE \
        -out "$CLIENT_CERT" \
        -days "$DAYS" \
        -"$DIGEST" \
        -extfile client.cnf \
        -extensions ext

    "$OPENSSL_BIN" pkcs12 -export \
        -in "$CLIENT_CERT" \
        -inkey "$CLIENT_KEY" \
        -certfile "$CA_CERT" \
        -out "$CLIENT_PFX" \
        -certpbe AES-256-CBC \
        -keypbe AES-256-CBC \
        -macalg sha256 \
        -passout pass:

    rm -f client.csr.pem client.cnf

    echo ""
    if [ "$GEN_VERBOSE" = "1" ]; then
        echo "--> 打印客户端证书"
        "$OPENSSL_BIN" x509 -in "$CLIENT_CERT" -text -noout
        echo ""
    fi
}

verify_cert() {
    echo "==> 验证证书链"

    if [ "$GEN_SERVER" = "1" ]; then
        echo "--> 验证服务端证书"
        "$OPENSSL_BIN" verify -CAfile "$CA_CERT" "$SERVER_CERT" || echo "服务端证书验证失败"
        echo ""
    fi

    if [ "$GEN_CLIENT" = "1" ]; then
        echo "--> 验证客户端证书"
        "$OPENSSL_BIN" verify -CAfile "$CA_CERT" "$CLIENT_CERT" || echo "客户端证书验证失败"
        echo ""
    fi
}

# 执行
if [ "$GEN_CA" = "1" ]; then
    generate_ca
fi

if [ "$GEN_SERVER" = "1" ]; then
    generate_server_cert
fi

if [ "$GEN_CLIENT" = "1" ]; then
    generate_client_cert
fi

verify_cert

echo "<<< End"
