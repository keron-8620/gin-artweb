#!/bin/sh


# ===================================================================
# 全局变量定义
# ===================================================================

HOME_PATH=$(cd `dirname $0`; pwd)
USER_NAME=${USER}
PROC_NUM=0

INIT_PID=1
TODAY=$(date "+%d")


# ===================================================================
# 打印帮助信息
# ===================================================================

Monitor_PrintUsage() {
    local _APP_NAME=${0}
    _APP_NAME=${_APP_NAME##*/}
    printf "\n\033[33mUsage: sh "${_APP_NAME}" [ Options ]\033[0m\n"
    printf "\n\033[33mOptions:\033[0m\n"
    printf "\033[33m  -h, --help                显示帮助信息\033[0m\n"
    printf "\033[33m  -U, --user                指定 MDS 所在系统用户名称, 默认获取当前登陆用户名称. 例: -U=XXX, --user=XXX\033[0m\n"
    printf "\n"
}


# ===================================================================
# 打印所有MDS系统进程信息
# ===================================================================

Monitor_PrintProcInfo() {
    ps -eo user,pid,ppid,lstart,etime,comm,args | sort -k2 \
    | grep -E "^${USER_NAME}" | grep -v grep \
    | awk -F' ' '
            BEGIN {}
            # -------------------------


            #
            # 判断处理器的主控进程是否已退出
            #
            # @param    manName     子系统名称(主控进程名称)
            # @param    procName    处理器进程名称
            # @param    ppid        处理器进程的父进程ID
            #
            function __Monitor_IsMainProcExit(mainName, procName, ppid) {
                if (ppid == '$INIT_PID') {
                    split(mainName, arr, "\/")
                    if (length(arr) > 0) {
                        mainName = arr[length(arr)]
                    }

                    if (length(mainName) > 0 && mainName != procName) {
                        return 1
                    }
                }

                return 0
            }
            # -------------------------


            {
                # 根据主控进程名过滤
                if ($11~/collector|latency|monagent|sequencer|scheduler|TT| \
                        |mds|broadcaster|l2_collector_sse|l2_collector_szse| \
                        |processor|publisher|forwarder|querier|tick_store|order_book/) {

                    skip = 0

                    # 检查MDS服务进程运行状态
                    if ($6 != '$TODAY') {
                        status = "\033[31m异常    \033[0m"
                        details = "\033[34m启动时间异常, 没有执行reset?    \033[0m"
                    } else if ($3 == '$INIT_PID') {
                        if (__Monitor_IsMainProcExit($11, $10, $3)) {
                            status = "\033[31m异常    \033[0m\033[0m"
                            details = "\033[34m主控进程已退出!                 \033[0m"
                        } else {
                            skip = 1
                        }
                    } else {
                        status = "\033[32m正常    \033[0m"
                        details = "-"
                    }

                    if (! skip) {
                        stime = $5" "$6" "$7" "$8
                        #user, pid, ppid, pname(comm), starttime, elapsedtime, status, details
                        printf "|%-8s|%-8s|%-16s|%-16s|%-22s|%-13s|%-8s|%-32s|\n", $2,$3,$11,$10,stime,$9,status,details
                    }
                }
            }
            # -------------------------


            END {}
            # -------------------------
            '
}


Monitor_Main() {
    PROC_NUM=`Monitor_PrintProcInfo | wc -l`
    NORMAL_NUM=`Monitor_PrintProcInfo | grep "正常" | wc -l`
    ABNORMAL_NUM=`Monitor_PrintProcInfo | grep "异常" | wc -l`

    printf "\n\n------------------------------------------------------------------------------------------------------------------------------------\n"
    printf "|%-8s|%-8s|%-16s|%-16s|%-22s|%-13s|%-8s|%-32s|\n" "PID" "PPID" "PNAME" "COMM" "START TIME" "ELAPSED TIME" "STATUS" "DETAILS"
    printf "|----------------------------------------------------------------------------------------------------------------------------------|\n"
    Monitor_PrintProcInfo
    printf "|----------------------------------------------------------------------------------------------------------------------------------|\n"
    printf "| 共 %2d 个由MDS创建的进程, \033[32m正常\033[0m [%2d] 个, \033[31m异常\033[0m [%2d] 个 %-77s|" \
            $PROC_NUM $NORMAL_NUM $ABNORMAL_NUM " "
    printf "\n------------------------------------------------------------------------------------------------------------------------------------\n"
}

##############################################
# Execute Main()
##############################################

if [ "$#" -gt "0" ]
then
        for params
        do
            case $params in
            #### 查看帮助
            -h|--help)
                Monitor_PrintUsage
                exit
                ;;

            #### 获取MDS主机用户名称
            -U=*)
                USER_NAME="`echo $params | cut -c4-`"
                ;;
            --user=*)
                USER_NAME="`echo $params | cut -c8-`"
                ;;

            #### 其他则显示帮助信息
            *)
                Monitor_PrintUsage
                exit
                ;;
            esac
        done
fi


BIN=${HOME_PATH%/*}"/bin"
if [ ! -d "${BIN}" ];then
    printf "\n\033[33m[NOTE] bin目录不存在, 脚本所在目录非bin/sbin??? local["${HOME_PATH}"], bin["${BIN}"]\033[0m\n"
    exit
fi


if [ -z "$USER_NAME" ];then
    Monitor_PrintUsage

    printf "\n\033[33m[NOTE] 请指定 [ -U=XXX 或 --user=XXX ] MDS系统所在主机用户名称后运行脚本!!!\033[0m\n\n"
    exit
fi


# 打印进程信息
Monitor_Main

