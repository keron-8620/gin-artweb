#!/bin/sh

##############################################
# 全局变量定义
##############################################

HOME_PATH=$(cd `dirname $0`; pwd)
MASTER_PROC_NAME="mds"
USER_NAME=${USER}
PROC_NUM=0
PRINT_PROC=true
EXEC_CONFIRM=false

CHECK_STATUS=0
RUN_TIME=0
IGNORE_PPID=1
TODAY=$(date "+%d")

# 预设的完整子系统列表
MDS_SUBSYS_LIST="                                                           \
collector               latency                     monagent                \
sequencer               scheduler                                           \
                                                                            \
mds                     broadcaster                 l2_collector_sse        \
l2_collector_szse       processor                   publisher               \
forwarder               querier                     tick_store              \
order_book                                                                  \
                                                                            \
TT"


##############################################
# 执行帮助
##############################################

KillMDS_Help() {
    local _APP_NAME=${0}
    _APP_NAME=${_APP_NAME##*/}
    printf "\n\033[33mUsage: sh "${_APP_NAME}" [ Options ]\033[0m\n"
    printf "\n\033[33mOptions:\033[0m\n"
    printf "\033[33m  -h, --help                显示帮助信息\033[0m\n"
    printf "\033[33m  -U, --user                指定 MDS 所在系统用户名称, 默认获取当前登陆用户名称. 例: -U=XXX, --user=XXX\033[0m\n"
    printf "\033[33m  -S, --subsys-list         指定 待停止的 MDS子系统名称. 例: -Smonagent,latency, --subsys-list=XXX,YYY\033[0m\n"
    printf "\033[33m  -Q, --quiet               屏蔽打印 MDS 系统进程信息\033[0m\n"
    printf "\033[33m  -Y, --yes                 确认执行强制停止 MDS 进程的指令\033[0m\n"
    printf "\033[33m  -C, --check               仅检查并输出系统运行状态, 不执行kill操作\033[0m\n"
    printf "\033[33m  -n, --non-execution       仅检查并输出系统运行状态, 不执行kill操作 (作用与[-C]参数一致)\033[0m\n"
    printf "\033[33m  -r, --runtime             检查并输出系统运行状态的运行时间(秒), 时间到达后脚本自动退出. 需与[-n]或[-C]参数配合使用. 例: -n -r30 \033[0m\n"
    #printf "\033[33m  -I, --ignorePPid          忽略对父进程为ppid进程运行状态的显示, 需与[-C]参数配合使用. 例: -C -I=1, -C --ignorePPid=1\033[0m\n"
    #printf "\033[33m                            注: 因父进程为1号的进程reset后启动时间不会改变, 故不需关注\033[0m\n"
    printf "\n"
}


##############################################
# 打印所有MDS系统进程信息
##############################################

KillMDS_Print_Pid_Pname() {
    ps -eo user,pid,ppid,lstart,args,etime,comm | sort -k 9 \
        | grep -E "^${USER_NAME}" |grep -v grep \
        | awk -v var="${MDS_SUBSYS_LIST}" \
        '
            BEGIN {
                split(var, list, "[ ,]");
                for (i = 1; i <= length(list); i++) {
                    _SUBSYS_LIST[list[i]] = i
                }
            }

            {
                split($9, arr, "/")
                if (length(arr) > 0) {
                    processName = arr[length(arr)]
                }

                if (processName in _SUBSYS_LIST) {
                    if ('$CHECK_STATUS' == 1) {
                        if ($3 != '$IGNORE_PPID') {
                            _status="\033[32m正常\033[0m"
                            if ($6 != '$TODAY')  {
                                _status="\033[31m异常\033[0m"
                            }

                            #"PID" "PPID" "PNAME" "COMM" "START TIME" "ELAPSED TIME" "STATUS"
                            printf "|%-8s|%-8s|%-24s|%-16s|%s %s %s %s %s |%-13s|%s    |\n", \
                                    $2,$3,$9,$12,$4,$5,$6,$7,$8,$11,_status
                        }
                    } else {
                        # "PID" "PPID" "PNAME" "COMM"
                        printf "|%-12s|%-12s|%-24s|%-16s|\n", $2,$3,$9,$12
                    }
                }
            }

            END {}
        '
}


KillMDS_Print() {
    PROC_NUM=`KillMDS_Print_Pid_Pname | wc -l`

    if [ "${PRINT_PROC}" = "true" ];then
        printf "\n\n---------------------------------------------------------------------\n"
        printf "\033[47;30;4m|%-12s|%-12s|%-24s|%-16s|\033[0m\n" "PID" "PPID" "PNAME" "COMM"
        printf "|-------------------------------------------------------------------|\n"
        KillMDS_Print_Pid_Pname
        printf "|-------------------------------------------------------------------|\n"
        printf "| 共 [%2d] 个由用户 [\033[34m%-8s\033[0m]通过MDS创建的进程  %20s|" $PROC_NUM $USER_NAME
        printf "\n---------------------------------------------------------------------\n"
    fi
}


KillMDS_CheckRunningStatus() {
    local _STATUS_CMD="./$0 -n -U${USER_NAME}"

    BUILD_HOST="`uname | tr '[A-Z]' '[a-z]'`"
    case $BUILD_HOST in
    linux)
        if [ $RUN_TIME -gt 0 ];then
            timeout --foreground ${RUN_TIME}s watch -t -d -n1 --color $_STATUS_CMD
        else
            watch -t -d -n1 --color $_STATUS_CMD
        fi

        $_STATUS_CMD
        ;;

    *)
        START_TIME=`date +%s`
        while true
        do
            clear && $_STATUS_CMD; sleep 1;

            CTIME=`date +%s`
            RUNNING_TIME=$[ $CTIME - $START_TIME ]
            if [ $RUN_TIME -gt 0 ] && [ $RUNNING_TIME -gt $RUN_TIME ]; then
                break;
            fi
        done
        ;;
    esac
}


KillMDS_CheckRunningStatusOnce() {
    PROC_NUM=`KillMDS_Print_Pid_Pname | wc -l`
    NORMAL_NUM=`KillMDS_Print_Pid_Pname | grep "正常" | wc -l`
    ABNORMAL_NUM=`KillMDS_Print_Pid_Pname | grep "异常" | wc -l`

    printf "\n--------------------------------------------------------------------------------------------------------------\n"
    printf "\033[47;30;4m|%-8s|%-8s|%-24s|%-16s|%-25s|%-13s|%-8s|\033[0m\n" \
            "PID" "PPID" "PNAME" "COMM" "START TIME" "ELAPSED TIME" "STATUS"
    printf "|------------------------------------------------------------------------------------------------------------|\n"
    KillMDS_Print_Pid_Pname
    printf "|------------------------------------------------------------------------------------------------------------|\n"
    printf "| 共 [%2d] 个由用户 [\033[34m%-8s\033[0m] 通过MDS创建的进程, \033[32m正常\033[0m [%2d] 个, \033[31m异常\033[0m [%2d] 个 %-33s|" \
            $PROC_NUM $USER_NAME $NORMAL_NUM $ABNORMAL_NUM " "
    printf "\n|------------------------------------------------------------------------------------------------------------|\n"
}


##############################################
# 筛选并KILL当前用户下所有宽睿系统的进程
##############################################

KillMDS_BySignal() {
    local _KILL_PARAM=15
    local _COUNTER=0

    if [ "$#" -gt "0" ]; then
        _KILL_PARAM=$1
    fi

    KillMDS_Print_Pid_Pname \
        | while read line;
          do
              PID=`echo $line | awk -F '|' '{ print $3 }'`
              PNAME=`echo $line | awk -F '|' '{ print $4 }'`

              _COUNTER=$((1 + $_COUNTER))
              #printf "\033[33m[INFO] %2d. kill -%2s %-6s %s\033[0m\n" ${_COUNTER} ${_KILL_PARAM} ${PID} ${PNAME}
              kill -${_KILL_PARAM} $PID >/dev/null 2>&1
          done
}


KillMDS_ByCmdLine() {
    local _STOP_PARAM="-F"

    if [ $# -gt 0 ]; then
        _STOP_PARAM=$1
    fi

    KillMDS_Print_Pid_Pname \
        | while read line;
          do
              _PPID=`echo $line | awk -F '|' '{ print $3 }'`
              _PNAME=`echo $line | awk -F '|' '{ print $4 }'`

              if [ ${_PPID} -eq 1 ]; then
                ../bin/${_PNAME} stop ${_STOP_PARAM}
              fi
          done
}


KillMDS_KillAll() {
    # 先执行一遍强制停止mds系统
    ../bin/mds sp -F

    # kill -15 proc
    KillMDS_BySignal 15

    sleep 1;

    # kill -9  proc
    KillMDS_BySignal 9

    # 释放 mds 共享内存
    PROC_NUM=`KillMDS_Print_Pid_Pname | wc -l`
    if [ ${PROC_NUM} -gt 0 ];then
        ../bin/mds sp -F
    fi
}


KillMDS_KillSpecial() {
    # .先执行一遍强制停止子系统
    KillMDS_ByCmdLine

    # kill -15 proc
    KillMDS_BySignal 15

    sleep 1;

    # kill -9  proc
    KillMDS_BySignal 9
}


##############################################
# Execute Main()
##############################################

if [ "$#" -gt "0" ]
then
    for params
    do
        case $params in
        #### 查看帮助
        -h|--help)
            KillMDS_Help
            exit
            ;;

        #### 确认执行
        -Y|--yes)
            EXEC_CONFIRM=true
            ;;

        #### 获取MDS主机用户名称
        -U=*)
            USER_NAME="`echo $params | cut -c4-`"
            ;;
        -U*)
            USER_NAME="`echo $params | cut -c3-`"
            ;;
        --user=*)
            USER_NAME="`echo $params | cut -c8-`"
            ;;

        #### 检查并输出系统状态
        -C|--check)
            CHECK_STATUS=1
            ;;

        #### 检查并输出系统状态
        -n|--non-execution)
            CHECK_STATUS=1
            ;;

        #### 检查并输出系统运行状态的运行时间(秒)
        -r*)
            RUN_TIME="`echo $params | cut -c3-`"
            ;;
        --runtime=*)
            RUN_TIME="`echo $params | cut -c11-`"
            ;;

        #### 忽略对父进程为ppid进程的检查
        -I=*)
            IGNORE_PPID="`echo $params | cut -c4-`"
            ;;
        --ignorePPid=*)
            IGNORE_PPID="`echo $params | cut -c14-`"
            ;;

        #### 指定待停止的子系统列表
        -S*)
            MDS_SUBSYS_LIST="`echo $params | cut -c3-`"
            ;;
        --subsys-list=*)
            MDS_SUBSYS_LIST="`echo $params | cut -c15-`"
            ;;

        #### 打印进程信息
        -Q|--quiet)
            PRINT_PROC=false
            ;;

        #### 其他则显示帮助信息
        *)
            KillMDS_Help
            exit
            ;;
        esac
    done
fi


BIN=${HOME_PATH%/*}"/bin"
if [ ! -d "${BIN}" ];then
    printf "\n\033[33m[NOTE] bin目录不存在, 脚本所在目录非bin/sbin??? local["${HOME_PATH}"], bin["${BIN}"]\033[0m\n"
    exit
fi


if [ -z "$USER_NAME" ];then
    KillMDS_Help

    printf "\n\033[33m[NOTE] 请指定 [ -U=XXX 或 --user=XXX ]MDS系统所在主机用户名称后运行脚本!!!\033[0m\n\n"
    exit
fi


if [ "${CHECK_STATUS}" = "1" ]; then
    if [ ${RUN_TIME} -ne 0 ]; then
        KillMDS_CheckRunningStatus
    else
        KillMDS_CheckRunningStatusOnce
    fi

    exit
fi


# 打印进程信息
KillMDS_Print

if [ ${PROC_NUM} -gt 0 ]; then
    if [ "${EXEC_CONFIRM}" = "false"  ]; then
        # 交互式确认继续执行强制停止MDS系统
        input=""
        tips=""

        while [ -z "$input" ]
        do
            printf "\n\033[33m[NOTE] 是否强制停止用户["${USER_NAME}"]下以上MDS系统进程? \033[0m\n"
            read -p  "choose[Y/N]:" input
        done

        inputLower=$(echo $input | tr '[A-Z]' '[a-z]')
        if [ "$inputLower" != 'y' ] && [ "$inputLower" != 'yes' ]; then
            printf "\n\033[33m[INFO] 输入待停止的子系统, 多个子系统以','分割, 为空则直接退出脚本... \033[0m\n"

            read -p  "subsystem-list:" MDS_SUBSYS_LIST

            # 输入空则退出
            if [ -z "$input" ]; then
                printf "\n\033[33m[INFO] 终止运行强制停止用户["${USER_NAME}"]下所有MDS系统进程的脚本! InputParam["${input}"]\033[0m\n"
                exit
            fi

            # 打印进程信息
            KillMDS_Print
        fi
    fi

    # 停止MDS系统或指定的子系统
    PROC_NUM=`KillMDS_Print_Pid_Pname | wc -l`
    if [ ${PROC_NUM} -gt 0 ]; then
        printf "\n\033[33m[NOTE] 3秒后将强制停止用户["${USER_NAME}"]下以上MDS系统进程...\033[0m\n"
        sleep 3

        # 判断是否停止MDS系统
        _IS_KILL_MDS=`echo $MDS_SUBSYS_LIST | grep -w $MASTER_PROC_NAME | wc -l`

        if [ ${_IS_KILL_MDS} -gt 0 ]; then
            KillMDS_KillAll
        else
            KillMDS_KillSpecial
        fi
    fi
fi

PROC_NUM=`KillMDS_Print_Pid_Pname | wc -l`
if [ ${PROC_NUM} -gt 0 ]; then
    printf "\n\033[33m[ERROR] 仍有残留进程! 数量["${PROC_NUM}"]\033[0m\n"
else
    printf "\n\033[33m[INFO] 强行停止用户["${USER_NAME}"]下MDS进程指令执行成功!\033[0m\n"
fi
