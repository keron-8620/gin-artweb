#!/bin/sh
#
# MDS 行情网关模拟器延迟统计脚本
#
# 参数列表 (延迟统计):
# - $1: Client tester recv time file path
# - $2: MDGW simulator sending time file path
# - $3: 0:do not compare, 1:compare before calculate, 2:compare only
#
# 参数列表 (to_csv 格式转换):
# - $1: to_csv
# - $2: latency summary info file path
#
# TESTER行情数据字段列表:
# - recordNum (从0开始递增)
# - dataType (0:逐笔委托, 1:逐笔成交, 2:L2快照, 3:L1快照)
# - SecurityID
# - ChannelNo
# - ApplSeqNum / TotalVolumeTraded
# - clRecvTime
# - TransactTime / updateTime
#
# 网关模拟器时间戳文件格式: (起始字段列表)
# - recordNum
# - dataType (0:逐笔委托, 1:逐笔成交, 2:L2快照, 3:L1快照)
# - SecurityID
# - ChannelNo
# - ApplSeqNum / TotalVolumeTraded
# - sendingTime
# - sentDoneTime
#

TESTER_LATENCY_FILE="$1"
SIMULATOR_LATENCY_FILE="$2"
COMPARE_FLAG="$3"


# to_csv 格式转换处理
if [ "$TESTER_LATENCY_FILE" = "to_csv" ] \
        || [ "$TESTER_LATENCY_FILE" = "TO_CSV" ]
then
    if [ -z "$SIMULATOR_LATENCY_FILE" ]
    then
        SIMULATOR_LATENCY_FILE="*.summary.txt"
    fi

    echo "# TO_CSV: [$SIMULATOR_LATENCY_FILE]"
    echo "#mean,min,max,Median,P80,P90,P95,P99,P99.99"
    echo ""

    for i in $(ls $SIMULATOR_LATENCY_FILE)
    do
        echo ">>>>> $i <<<<<"

        sed -ne 's/^.*, mean\[\([0-9\.\-]*\)\], min\[\([0-9\.\-]*\)\], max\[\([0-9\.\-]*\)\], Median\[\([0-9\.\-]*\)\], P80\[\([0-9\.\-]*\)\], P90\[\([0-9\.\-]*\)\], P95\[\([0-9\.\-]*\)\], P99\[\([0-9\.\-]*\)\], P99.99\[\([0-9\.\-]*\)\].*$/\1,\2,\3,\4,\5,\6,\7,\8,\9/p' $i

        echo ""
    done

    echo ""
    exit 0
fi


# 延迟统计处理
if [ -z "$SIMULATOR_LATENCY_FILE" ] || [ "$SIMULATOR_LATENCY_FILE" = "-h" ] \
        || [ -z "$TESTER_LATENCY_FILE" ] || [ "$TESTER_LATENCY_FILE" = "-h" ] \
        || ([ -n "$COMPARE_FLAG" ] && [ "$COMPARE_FLAG" != "0" ] \
                && [ "$COMPARE_FLAG" != "1" ] && [ "$COMPARE_FLAG" != "2" ])
then
    echo ""
    echo "Usage1: ./mds_simulator_latency_stats.sh client_recv_time.txt simulator_sending_time.txt [compare_flag]"
    echo "Params:"
    echo "    #1  Client tester recv time file path"
    echo "    #2  MDGW simulator sending time file path"
    echo "    #3  compare flag (0:do not compare (default), 1:compare before calculate, 2:compare only)"
    echo "Examples:"
    echo "    ./mds_simulator_latency_stats.sh mkdata_recv_time.txt mkdata_send_time.txt"
    echo ""
    echo ""
    echo "Usage2: ./mds_simulator_latency_stats.sh to_csv 'file_path'"
    echo "Params:"
    echo "    #1  to_csv"
    echo "    #2  latency summary info file path"
    echo "Examples:"
    echo "    ./mds_simulator_latency_stats.sh to_csv 'result_20220526/*.txt'"
    echo ""
    echo ""
    exit 1
elif [ ! -f "$SIMULATOR_LATENCY_FILE" ]
then
    echo ""
    echo "ERROR: not found file '$SIMULATOR_LATENCY_FILE'"
    echo ""
    exit 1
elif [ ! -f "$TESTER_LATENCY_FILE" ]
then
    echo ""
    echo "ERROR: not found file '$TESTER_LATENCY_FILE'"
    echo ""
    exit 1
fi


# 检查统计数据是否匹配
SIM_TOTAL_CNT=$(cat "$SIMULATOR_LATENCY_FILE" | wc -l)
SIM_TOTAL_CNT1=$(cat "$TESTER_LATENCY_FILE" | wc -l)

if [ "$SIM_TOTAL_CNT" -ne "$SIM_TOTAL_CNT1" ]
then
    echo ""
    echo "ERROR: 客户端和服务器端数据文件行数不匹配!"
    echo ">   $TESTER_LATENCY_FILE: $SIM_TOTAL_CNT1"
    echo ">   $SIMULATOR_LATENCY_FILE: $SIM_TOTAL_CNT"
    echo ""
    exit 1
fi

if [ -n "$COMPARE_FLAG" ] && [ "$COMPARE_FLAG" != "0" ]
then
    # 比较客户端和服务器端数据是否一致 (前5个字段)
    cut -d, -f1-5 "$SIMULATOR_LATENCY_FILE" > start_fields_sim.txt.TMP~
    cut -d, -f1-5 "$TESTER_LATENCY_FILE" > start_fields_tester.txt.TMP~

    cmp start_fields_sim.txt.TMP~ start_fields_tester.txt.TMP~
    if [ "$?" -ne "0" ]
    then
        echo ""
        echo "ERROR: 客户端和服务器端数据不匹配!"
        echo ">   diff start_fields_sim.txt.TMP~ start_fields_tester.txt.TMP~"
        echo ""
        exit 1
    fi

    if [ "$COMPARE_FLAG" == "2" ]
    then
        echo ""
        echo "INFO: compare ok!"
        echo ">   $SIMULATOR_LATENCY_FILE: $SIM_TOTAL_CNT"
        echo ">   $TESTER_LATENCY_FILE: $SIM_TOTAL_CNT1"
        echo ""

        rm -f *.txt.TMP~ 2> /dev/null
        exit 0
    fi
fi

export SIM_TOTAL_CNT


####################
# 全路径延迟
####################

# 计算行情延迟
# - 1,2: sendingTime
# - 8,9: clRecvTime
cut -d, -f6 "$SIMULATOR_LATENCY_FILE" \
| paste -d, - "$TESTER_LATENCY_FILE" \
| awk -F'[,.]' ' \
  {sendSec=$1+0; sendNs=$2+0; recvSec=$8+0; recvNs=$9+0; \
    l=(recvSec-sendSec)*1000000 + (recvNs-sendNs)/1000.0; \
    printf "%.3f,%d.%09d,%d.%09d\n", l, sendSec, sendNs, recvSec, recvNs}' \
> simulator_latency_result.list.txt


# 排序行情延迟
# - 1: latency
# - 2,3: sendingTime
# - 4,5: clRecvTime
cat simulator_latency_result.list.txt \
| sort -n -t',' -k1 \
> simulator_latency_result.sort.txt


# 计算统计信息
awk ' \
  BEGIN{totalCnt=ENVIRON["SIM_TOTAL_CNT"]; min=99999999.0; max=0.0; sum=0.0; c50=int(totalCnt/2); c80=int(totalCnt*0.8); c90=int(totalCnt*0.9); c95=int(totalCnt*0.95); c99=int(totalCnt*0.99); c999=int(totalCnt*0.9999);} \
  { l=$1+0; \
    if (l > 0) { \
      sum+=l; \
      if (min > l) min=l; \
      if (max < l) max=l; \
    } \
    if (NR == c50) l50=l; \
    else if (NR == c80) l80=l; \
    else if (NR == c90) l90=l; \
    else if (NR == c95) l95=l; \
    else if (NR == c99) l99=l; \
    else if (NR == c999) l999=l; \
  } \
  END{printf "count[%d], mean[%.3f], min[%.3f], max[%.3f], Median[%.3f], P80[%.3f], P90[%.3f], P95[%.3f], P99[%.3f], P99.99[%.3f]\n", NR, sum/NR, min, max, l50, l80, l90, l95, l99, l999}' \
simulator_latency_result.sort.txt \
> simulator_latency_result.summary.txt


# 输出统计信息
echo ">>>>> Summary: (simulator_latency_result.summary.txt)"
cat simulator_latency_result.summary.txt
echo ""


rm -f *.txt.TMP~ 2> /dev/null
rm -f *.sort.txt 2> /dev/null
rm -f *.list.txt 2> /dev/null

exit 0
