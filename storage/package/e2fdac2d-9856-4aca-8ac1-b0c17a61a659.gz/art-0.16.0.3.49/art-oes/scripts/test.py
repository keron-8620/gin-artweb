import time


curr_date = time.strftime('%Y%m%d')
print(curr_date[:4])
