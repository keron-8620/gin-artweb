                                       自动化运维工具说明

1. 查询版本信息
    sh art.sh -v
    sh art.sh --version
2. 查询运行状态信息
    1) 所有运行状态
        sh art.sh -t
        sh art.sh --status
    2) 对应任务运行状态
        sh cmd/任务.sh -t
        sh cmd/任务.sh --status
3. 查询帮助
    1) 所有帮助
        sh art.sh -h
        sh art.sh --help
    2) 对应任务帮助
        sh cmd/任务.sh -h
        sh cmd/任务.sh --help
