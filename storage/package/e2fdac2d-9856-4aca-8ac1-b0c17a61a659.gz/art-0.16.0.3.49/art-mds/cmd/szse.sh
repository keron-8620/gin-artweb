#!/usr/bin/env bash

_curr_date=$(date +%Y%m%d)

basepath=$(cd `dirname $0`; pwd)

cd $basepath/..

export ANSIBLE_SSH_CONTROL_PATH_DIR=~/.ansible/szse

action="szse_collector"

TEMP=`getopt -o d:c -a -l date:,cmd_mds -n "test.sh" -- "$@"`
# 判定 getopt 的执行时候有错，错误信息输出到 STDERR
# 选项后接一个冒号表示其后为其参数值，选项后接两个冒号表示其后可以有也可以没有选项值，选项后没有冒号表示其后不是其参数值
if [ $? != 0 ]
then
	echo "Terminating....." >&2
	exit 1
fi

eval set -- "$TEMP"

while true
do
    case "$1" in
        -d | --date)
            date="$2"
            /usr/local/bin/python3 scripts/action.py -a $action -d $date
            shift
            break
            ;;
        -c | --cmd_mds)
            /usr/local/bin/python3 scripts/action.py -a $action -c
            shift
            break
            ;;

        --)
            /usr/local/bin/python3 scripts/action.py -a $action
            shift
            break
            ;;
        *)
            echo "Internal error!"
            exit 1
            ;;

    esac
done
